"use strict";
function CartService($http){
    const self = this;
    self.getAllItems = function(){//GET
        return $http({
            method: "GET",
            url: "/cart-items"
        });
    };
    self.deleteCartItems = function(cartItems) {//DELETE
        return $http({
            method: "DELETE",
            url: `/cart-items/${cart-items}`
        });
    };
    self.addCartItems = function(newCartItems){//POST
        return $http({
            method: "POST",
            url: "/cart-items",
            data: { cartItems: newCartItems }
        });
    };

    self.editCartItems = function(cartItems, newCartItems){//PUT
        return $http({
            method: "PUT",
            url: `/cart-items/${cart-items}`,
            data: {cartItems: newCartItems}
        });
    };
}

angular
.module("App")
.service("CartService", CartService);