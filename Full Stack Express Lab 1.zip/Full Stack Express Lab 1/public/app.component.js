"use strict";

const cartItems = {
    template: `
    <p class="title">Cart Items</p>
    <section ng-repeat="item in $ctrl.cartList track by $index">
    <p>Id: {{ item.id }} </p>
    <p>Product: {{ item.product }}</p>
    <p>Price: {{ item.price }}</p>
    <p>Quantity: {{ item.quantity }}</p>
    </section>
    <button>Add</button>
    <button>Delete</button>
    
    `,
     controller: ["CartService", function(CartService){
        const vm = this;

        CartService.getAllItems().then(response => {//GET
            console.log(response);
            vm.cartList = response.data;
        });
        vm.editCartItems = function(cartItems, newCartItems){//PUT
            CartService.editCartItems(cartItems, newCartItems).then(response => {
                vm.cartList = response.data;
             });
        };
        vm.addCartItems = function (newCartItems) {//POST
            CartService.addCartItems(newCartItems).then(response => {
                vm.cartList = response.data
            });
        };
        vm.deleteCartItems = function(cartItems){//DELETE
            CartService.deleteCartItems(cartItems).then(response => {
                vm.cartList = response.data;
            });
        };
    }]
};

angular
.module("App")
.component("cartItems", cartItems);


{/* <input type="text" placeholder="Product" ng-model="newCartItem">
    <input type="number" placeholder="Price">
    <input type="number" placeholder="Quantity"></input> */}