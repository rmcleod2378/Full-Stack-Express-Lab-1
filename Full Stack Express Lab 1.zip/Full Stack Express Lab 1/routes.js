"use strict";

const express = require("express");
const cartItems = express.Router();
const cartList = [
    { id: 0,
      product: "Apple",
      price: 1,
      quantity: 1,
    },
    { id: 1,
        product: "Banana",
        price: 2,
        quantity: 1,
      },
      { id: 2,
        product: "Carrot",
        price: 3,
        quantity: 1,
      },
];

cartItems.get("/cart-items", function(req, res){
    res.send(cartList);
    console.log("GET request made");
});

cartItems.get("/cart-items/:id", function (req, res){
  console.log("GET cart-items request made");
  for (let cartItems of cartList){
    if (cartItems === req.params.id){
      res.send(cartItems);
      break;
    } else {
      res.send("No cart items found");
    }
  }
});

cartItems.post("/cart-items", function(req, res){
    cartList.push(req.body);
    console.log("POST method made");
    res.send(cartList);
});

cartItems.delete("/cart-items/:id", function(req, res){
  for (let i = 0; i < cartList.length; i++){
    if (cartList[i].id == req.params.id){
      cartList.splice(i, 1);
      console.log("DELETE method made")
      res.send(cartList);
      break;
    }
  }
})
cartItems.put("/cart-items/:id", function(req, res){
    for (let i = 0; i < cartList.length; i++) {
        if(cartList[i] == req.params.id){
            cartList.splice(i, 1, req.body);
            console.log("PUT method made")
            res.send(cartList);
        }
    }
    console.log("PUT request made");

  });
module.exports = cartItems;